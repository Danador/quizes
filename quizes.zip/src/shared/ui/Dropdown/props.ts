export const DropdownProps = () => ({
    open: { type: Boolean, default: false },
    customClass: { type: String, default: '' },
});
