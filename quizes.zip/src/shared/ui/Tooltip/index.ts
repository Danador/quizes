import { Tooltip } from './index.tsx';
export { Tooltip };
