import { CopyBox } from './index.tsx'
export { CopyBox }