export const IconProps = () => ({
    name: { type: String, default: null },
    size: { type: String, default: 'big' },
});
