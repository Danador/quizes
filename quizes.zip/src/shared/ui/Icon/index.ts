import { Icon } from './index.tsx';
export { Icon };
