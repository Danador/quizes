import { CardFooter } from './index.tsx';
export { CardFooter };
