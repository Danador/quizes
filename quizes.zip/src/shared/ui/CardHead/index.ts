import { CardHead } from './index.tsx';
export { CardHead };
