import { Modal } from './index.tsx';
export { Modal };
