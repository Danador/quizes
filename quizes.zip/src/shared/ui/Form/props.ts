export const FormProps = () => ({
    cols: { type: Number, default: null },
    rows: { type: Number, default: null },
    action: { type: String, default: null },
    customClass: { type: String, default: null },
});
