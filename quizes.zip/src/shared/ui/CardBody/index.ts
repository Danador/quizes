import { CardBody } from './index.tsx';
export { CardBody };
