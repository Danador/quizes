import { previewData } from './data';
export { previewData };
