import { reactive } from 'vue';

export const previewData = reactive({});
