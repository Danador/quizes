import Preview from './index.vue';
export { Preview };
