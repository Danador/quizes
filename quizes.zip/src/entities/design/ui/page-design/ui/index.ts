import PageDesign from './index.vue';
export { PageDesign };
