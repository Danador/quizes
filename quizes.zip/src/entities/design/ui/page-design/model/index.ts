import { pageDesignData } from './data';
export { pageDesignData };
