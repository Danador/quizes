import { reactive } from 'vue';

export const pageDesignData = reactive({});
