import Templates from './index.vue';
export { Templates };
