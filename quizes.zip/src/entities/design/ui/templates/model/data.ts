import { reactive } from 'vue';

export const templatesData = reactive({});
