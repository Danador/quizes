import { templatesData } from './data';
export { templatesData };
