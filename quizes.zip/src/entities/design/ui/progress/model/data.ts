import { reactive } from 'vue';

export const progresData = reactive({});
