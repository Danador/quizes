import QuizSelected from './index.vue'
export { QuizSelected }
