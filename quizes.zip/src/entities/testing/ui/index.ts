import Testing from './index.vue'
export { Testing }
