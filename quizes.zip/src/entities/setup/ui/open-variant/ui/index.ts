import VariantOpen from './index.vue';
export { VariantOpen };
