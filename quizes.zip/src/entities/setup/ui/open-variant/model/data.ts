import { reactive } from 'vue';

export const dataVariantOpen = reactive({});
