import { dataVariantOpen } from './data';
export { dataVariantOpen };
