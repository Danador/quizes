import VariantBaner from './index.vue';
export { VariantBaner };
