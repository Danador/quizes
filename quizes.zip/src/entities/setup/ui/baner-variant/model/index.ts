import { dataVariantBaner, addBanerStyle } from './data';
export { dataVariantBaner, addBanerStyle };
