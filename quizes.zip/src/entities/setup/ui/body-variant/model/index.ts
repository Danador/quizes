import { dataVariantBody, addBodyStyle } from './data';
export { dataVariantBody, addBodyStyle };
