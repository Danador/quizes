import VariantBody from './index.vue';
export { VariantBody };
