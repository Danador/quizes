import PrivacyPolicy from './index.vue';
export { PrivacyPolicy };
