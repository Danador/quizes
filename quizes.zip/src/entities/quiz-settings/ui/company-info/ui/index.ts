import CompanyInfo from './index.vue'
export { CompanyInfo }
