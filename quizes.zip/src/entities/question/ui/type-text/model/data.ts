import { reactive } from 'vue';

export const dataTypeText = reactive({
    answers: [
        {
            id: 1,
            showHint: true,
        },
        {
            id: 2,
        },
    ],
});
