import { dataTypeText } from './data';
export { dataTypeText };
