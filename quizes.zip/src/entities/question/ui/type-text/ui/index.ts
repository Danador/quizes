import TypeText from './index.vue';
export { TypeText };
