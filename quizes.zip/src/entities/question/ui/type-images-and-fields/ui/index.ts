import TypeImagesAndFields from './index.vue';
export { TypeImagesAndFields };
