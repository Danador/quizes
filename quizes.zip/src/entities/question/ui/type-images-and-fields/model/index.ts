import { dataTypeFieldsAndImages } from './data';
export { dataTypeFieldsAndImages };
