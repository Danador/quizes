import { reactive } from 'vue';

export const dataTypeFieldsAndImages = reactive({
    answers: [
        {
            id: 1,
            showHint: true,
        },
        {
            id: 2,
        },
    ],
});
