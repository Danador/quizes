import TypeDate from './index.vue';
export { TypeDate };
