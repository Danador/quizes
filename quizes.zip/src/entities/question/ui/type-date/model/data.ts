import { reactive } from 'vue';

export const dataTypeDate = reactive({
    dateType: 'mask',
});
