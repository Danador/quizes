import { dataTypeRange } from './data';
export { dataTypeRange };
