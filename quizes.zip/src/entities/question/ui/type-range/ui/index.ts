import TypeRange from './index.vue';
export { TypeRange };
