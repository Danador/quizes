import { dataTypeCards } from './data';
export { dataTypeCards };
