import TypeCards from './index.vue';
export { TypeCards };
