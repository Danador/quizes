import { reactive } from 'vue';

export const dataTypeDropdown = reactive({
    answers: [
        {
            id: 1,
        },
        {
            id: 2,
        },
    ],
});
