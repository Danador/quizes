import TypeFields from './index.vue';
export { TypeFields };
