import { reactive } from 'vue';

export const dataTypeFields = reactive({
    answers: [
        {
            id: 1,
            showHint: true,
        },
        {
            id: 2,
        },
    ],
});
