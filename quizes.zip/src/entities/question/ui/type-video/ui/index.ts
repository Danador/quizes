import TypeVideo from './index.vue';
export { TypeVideo };
