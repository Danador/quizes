import { reactive } from 'vue';

export const dataTypeVideo = reactive({
    videoType: 'link',
});
