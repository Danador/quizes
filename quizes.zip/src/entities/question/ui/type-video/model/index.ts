import { dataTypeVideo } from './data';
export { dataTypeVideo };
