import { reactive } from 'vue';

export const dataTypeDownload = reactive({});
