import TypeDownload from './index.vue';
export { TypeDownload };
