import QuizCard from './index.vue';
export { QuizCard };
