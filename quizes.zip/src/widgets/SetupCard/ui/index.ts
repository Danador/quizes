import SetupCard from './index.vue';
export { SetupCard }