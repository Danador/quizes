import CrmCard from './index.vue'
export { CrmCard }
