import StartSetting from './index.vue';
export { StartSetting };
