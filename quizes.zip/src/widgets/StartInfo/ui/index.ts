import StartInfo from './index.vue';
export { StartInfo };
