import Table from './index.vue';
export { Table };
