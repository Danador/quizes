import QuestionTypes from './index.vue';
export { QuestionTypes };
