import { type RowProps } from './table-row';
export type { RowProps };
