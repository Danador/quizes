import { SlideModal } from './index.tsx';
export { SlideModal };
