<script setup lang="ts">
  import { Routing } from '../pages';
</script>

<template>
  <Routing />
</template>

<style>
  @import "../styles/index.scss";
</style>
