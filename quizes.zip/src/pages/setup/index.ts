import QuizSetup from './index.vue';
export default QuizSetup;
