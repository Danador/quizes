import QuizDesign from './index.vue';
export default QuizDesign;
