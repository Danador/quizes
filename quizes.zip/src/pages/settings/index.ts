import QuizSettings from './index.vue';
export default QuizSettings;
