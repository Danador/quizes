import Quizes from './index.vue';
export default Quizes;
