import Integrations from './index.vue'
export default Integrations
