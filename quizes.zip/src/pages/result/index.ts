import Result from './index.vue';
export default Result;
