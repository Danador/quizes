import QuizStart from './index.vue';
export default QuizStart;
