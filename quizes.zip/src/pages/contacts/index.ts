import Contacts from './index.vue';
export default Contacts;
