import QuizTemplates from './index.vue';
export default QuizTemplates;
