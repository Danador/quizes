import Questions from './index.vue';
export default Questions;
