import DeleteBtn from './index.vue';
export { DeleteBtn };
