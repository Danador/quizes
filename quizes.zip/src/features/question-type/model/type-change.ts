import { ref } from 'vue';

export const questionType = ref({
    type: 'text-field',
});
