import CopyBtn from './index.vue';
export { CopyBtn };
