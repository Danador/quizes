import Managment from './index.vue';
export { Managment };
